#include "config.h"
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>

// For coloring output (optional)
#define RED   "\033[31m"
#define GREEN "\033[32m"
#define RESET "\033[0m"

// Unicode symbols for check and cross
#define CHECK "✔"
#define CROSS "❌"

static int tests_passed = 0;
static int tests_failed = 0;

int large_size = 10000;
// Utility: Create a large test file
static void generate_large_test_file(const char *filename, int size) {
    FILE *f = fopen(filename, "w");
    for (int i = 1; i <= size; i++) {
        fprintf(f, "%d ", i);
    }
    fclose(f);
}



static bool test_handle_page_fault_load_and_update() {
    int test_process_id = 0; // Test with process ID 0
    int test_page_number = 1; // Access page 1 (not in memory initially)
    int frame_before = find_free_frame(); // Find a free frame before the page fault
    
    // Simulate the page fault
    handle_page_fault(test_process_id, test_page_number);

    // Verify the page is loaded into the frame
    int frame_after = processes[test_process_id].page_table[test_page_number].frame_number;
    
    if (frame_after == -1){
        fprintf(stderr, "the page is not loaded into the frame\n");
        return false; // Ensure frame is assigned
    } 

    // Verify the page table entry is updated
    
    if (!processes[test_process_id].page_table[test_page_number].valid){
        fprintf(stderr, "the page table entry is not updated in valid mode\n");
        return false;
    }

    // Verify the physical memory contains the correct data
    for (int i = 0; i < PAGE_SIZE; i++) {
        if (physical_memory[frame_after][i] != backing_store[test_process_id * PAGE_SIZE + test_page_number].page_data[i]) {
            fprintf(stderr, "the physical memory does not contain the correct data\n");
            return false;
        }
    }

    return true; // All checks passed
}

static bool test_evicted_page_invalid() {
    int value1 = get_value(0, 0);
    int value2 = get_value(0, 4); // loads page 1
    int value3 = get_value(0, 8); // loads page 2, should evict page 0

    if (value1 != 0 || value2 != 4 || value3 != 8) {
        fprintf(stderr, "the values are not correct\n");
        return false;
    }

    Process *p = &processes[0];
    return (p->page_table[0].valid == false);
}

static bool test_get_value_func_few_pages(){
    int val0 = get_value(0,0);
    if (!(val0==0)){
        fprintf(stderr, "the value is not correct\n");
        return false;
    }

    int val5 = get_value(0,5);
    if (!(val5==5)){
        fprintf(stderr, "the value is not correct\n");
        return false;
    }

    return true;
}

static bool test_get_value_func() {
    int val0 = get_value(0,0);
    if (!(val0==0)) return false;

    int val5 = get_value(0,5);
    if (!(val5==5)) return false;

    int val9 = get_value(0,9);
    if (!(val9==9)) return false;

    int val_again = get_value(0,0);
    if (!(val_again==0)) return false;

    return true;
}

static bool test_lru_updates() {
    Process *p = &processes[0];
    get_value(0,0);
    unsigned long t0 = p->page_table[0].last_used;
    get_value(0,4);
    unsigned long t1 = p->page_table[1].last_used;
    get_value(0,0);
    unsigned long t2 = p->page_table[0].last_used;
    get_value(0,0);
    unsigned long t3 = p->page_table[0].last_used;

    if(t0 == t1 || t1 == t2 || t2 == t3) {
        fprintf(stderr, "the page tables have the same value, they need to be updated after they are requested.\n");
        return false;
    }
    return (t3 > t2 && t2 > t1 && t1 > t0);
}

static bool test_large_file_first() {
    return (get_value(1, 0) == 1);
}

static bool test_large_file_middle(int large_size) {
    return (get_value(1, large_size / 2) == (large_size / 2 + 1));
}

static bool test_large_file_last(int large_size) {
    return (get_value(1, large_size - 1) == (large_size));
}

static bool test_get_value_process_not_found() {
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return false;
    }

    if (pid == 0) {
        // Child process: call get_value with an invalid process ID
        get_value(9999, 0);
        // If it doesn't exit, return false
        _exit(1);
    } else {
        // Parent process: wait for the child
        int status;
        waitpid(pid, &status, 0);

        if (WIFEXITED(status) && WEXITSTATUS(status) == 2) {
            // Correct exit code for "process not found"
            return true;
        } else {
            return false;
        }
    }
}

static bool test_get_value_out_of_range() {
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return false;
    }

    if (pid == 0) {
        // Child process: call get_value with an out-of-range index
        get_value(0, 999999);
        // If it doesn't exit, return false
        _exit(1);
    } else {
        // Parent process: wait for the child
        int status;
        waitpid(pid, &status, 0);

        if (WIFEXITED(status) && WEXITSTATUS(status) == 3) {
            // Correct exit code for "out of range"
            return true;
        } else {
            return false;
        }
    }
}


// Run a test in a separate process
static void run_test(const char *test_name, bool (*test_func)(void)) {
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return;
    }

    if (pid == 0) {
        // Child: run the test
        bool result = test_func();
        _exit(result ? 0 : 1);
    } else {
        // Parent: wait for the child
        int status;
        waitpid(pid, &status, 0);

        if (WIFEXITED(status)) {
            int code = WEXITSTATUS(status);
            if (code == 0) {
                printf(GREEN "%s %s" RESET "\n", test_name, CHECK);
                tests_passed++;
            } else {
                printf(RED "%s %s" RESET "\n", test_name, CROSS);
                tests_failed++;
            }
        } else if (WIFSIGNALED(status)) {
            // Child crashed (e.g., segfault)
            printf(RED "segmentation fault: %s %s" RESET "\n", test_name, CROSS);
            tests_failed++;
        } else {
            // Some other termination condition
            printf(RED "%s %s" RESET "\n", test_name, CROSS);
            tests_failed++;
        }
    }
}

bool test_large_file_middle_func() {return test_large_file_middle(large_size);}
bool test_large_file_last_func() {return test_large_file_last(large_size);}

int main() {
    BACKING_STORE_SIZE = 10000;
    MEMORY_SIZE = 2;
    PAGE_SIZE = 4;
    NUM_PROCESSES = 2;

    processes = malloc(sizeof(Process)*NUM_PROCESSES);
    {
        FILE *f = fopen("processes/test1.txt","w");
        fprintf(f,"0 1 2 3 4 5 6 7 8 9");
        fclose(f);
    }

    processes[0] = read_process_from_file("processes/test1.txt", 0);
    setup_process_pages(&processes[0]);
    create_backing_store();
    init_physical_memory();

    printf("\n--- Running Tests ---\n");
    // Run tests line by line
    run_test("Evicted page is marked invalid", test_evicted_page_invalid);
    run_test("Handle page fault: Load page and update page table", test_handle_page_fault_load_and_update);
    run_test("allocate less pages than memory test", test_get_value_func_few_pages);
    run_test("allocate more pages than memory test : test for loading page into memory, delete the least used page and load the needed page again", test_get_value_func);

    run_test("LRU updates timestamps in order", test_lru_updates);

    printf("\n--- Running Stress Tests ---\n");
    processes[1] = (Process){.process_id = 1, .data=NULL, .data_count=0,.pages_count=0,.page_table=NULL};

    generate_large_test_file("processes/large_test.txt", large_size);

    processes[1] = read_process_from_file("processes/large_test.txt", 1);
    setup_process_pages(&processes[1]);
    create_backing_store();
    init_physical_memory();

    run_test("Large file: First value", test_large_file_first);
    // For these two, we need a small wrapper since they need parameters
    
    run_test("Large file: Middle value", test_large_file_middle_func);
    run_test("Large file: Last value", test_large_file_last_func);


    printf("\n--- Running Exception Tests ---\n");
    run_test("There is exception for process not found", test_get_value_process_not_found);
    run_test("There is exception for value out of range", test_get_value_out_of_range);

    int total = tests_passed + tests_failed;
    printf("\nSummary: %d/%d tests passed.\n", tests_passed, total);
    if (tests_failed == 0) {
        printf(GREEN "All tests passed " CHECK RESET "\n");
    } else {
        printf(RED "%d tests failed " CROSS RESET "\n", tests_failed);
    }

    return 0;
}
