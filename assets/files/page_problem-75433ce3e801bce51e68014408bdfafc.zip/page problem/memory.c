#include "config.h"

int **physical_memory = NULL;
Process *processes = NULL;
BackingStorePage *backing_store = NULL;

// Global variables (defined in config.h)
int BACKING_STORE_SIZE = 0;
int MEMORY_SIZE = 0;
int PAGE_SIZE = 0;
int NUM_PROCESSES = 0;

unsigned long global_time_counter = 0;

static bool *frame_occupied;   // keeps track of which frames are in use

static FrameMap *frame_map;

void init_physical_memory() {
    physical_memory = malloc(sizeof(int*)*MEMORY_SIZE);
    if(!physical_memory) {
        perror("malloc physical_memory");
        exit(EXIT_FAILURE);
    }

    for(int i=0; i<MEMORY_SIZE; i++){
        physical_memory[i] = malloc(sizeof(int)*PAGE_SIZE);
        if(!physical_memory[i]) {
            perror("malloc frame");
            exit(EXIT_FAILURE);
        }
    }

    frame_occupied = calloc(MEMORY_SIZE, sizeof(bool));
    if(!frame_occupied) {
        perror("calloc frame_occupied");
        exit(EXIT_FAILURE);
    }
    frame_map = malloc(sizeof(FrameMap)*MEMORY_SIZE);
    if(!frame_map) {
        perror("malloc frame_map");
        exit(EXIT_FAILURE);
    }
    for(int i=0; i<MEMORY_SIZE; i++){
        frame_map[i].process_id = -1;
        frame_map[i].page_number = -1;
    }
}

// Given a process_id and a page_number, returns the frame number where it is located.
// If not valid, return -1 and it will cause a page fault
int get_frame_for_page(int process_id, int page_number) {
    Process *p = NULL;
    for(int i=0; i<NUM_PROCESSES; i++){
        if(processes[i].process_id == process_id) {
            p = &processes[i];
            break;
        }
    }
    if(!p) {
        fprintf(stderr,"Process %d not found\n", process_id);
        exit(EXIT_FAILURE);
    }

    page_table_entry *entry = &p->page_table[page_number];
    if(entry->valid) {
        // Update LRU
        update_lru(process_id, page_number);
        return entry->frame_number;
    } else {
        return -1;
    }
}

int find_free_frame() {
    for(int i=0; i<MEMORY_SIZE; i++){
        if(!frame_occupied[i]) return i;
    }
    return -1;
}

int select_victim_frame() {
    // Use LRU: the victim frame is the one with the oldest last_used
    unsigned long oldest = ULONG_MAX;
    int victim_frame = -1;
    for(int i=0; i<MEMORY_SIZE; i++){
        int proc_id = frame_map[i].process_id;
        int pg_num = frame_map[i].page_number;
        if(proc_id == -1) continue; // empty frame shouldn't happen if we get here
        // Find the process to get its last_used
        Process *p = NULL;
        for(int j=0; j<NUM_PROCESSES; j++){
            if(processes[j].process_id == proc_id) {
                p = &processes[j];
                break;
            }
        }
        unsigned long lu = p->page_table[pg_num].last_used;
        if(lu < oldest) {
            oldest = lu;
            victim_frame = i;
        }
    }
    return victim_frame;
}

//TODO: This function should get a free frame or evict a victim, 
//load the requested page into this frame
//and update the page table entry and frame map
void handle_page_fault(int process_id, int page_number) {

}

//TODO: This function should update the last_used field of the page table entry 
//with the ++global_time_counter
void update_lru(int process_id, int page_number) {

}

//TODO: This function should return the value at the logical_index of the process
// If there is not a process with this id : exit(2);
// If index out of range : exit(3);
int get_value(int process_id, int logical_index) {
    return 0;
}
