#include "config.h"

void create_backing_store() {
    // BACKING_STORE_SIZE should be at least the sum of all pages from all processes
    int total_pages = 0;
    for(int i =0; i<NUM_PROCESSES; i++){
        total_pages += processes[i].pages_count;
    }

    if(total_pages > BACKING_STORE_SIZE) {
        fprintf(stderr,"Not enough backing store size to hold all pages\n");
        exit(EXIT_FAILURE);
    }

    backing_store = malloc(sizeof(BackingStorePage)*BACKING_STORE_SIZE);
    if(!backing_store) {
        perror("malloc backing_store");
        exit(EXIT_FAILURE);
    }

    int idx = 0;
    for(int i=0; i<NUM_PROCESSES; i++){
        Process *p = &processes[i];

        //fill the backing store with the pages of the process
        for(int page=0; page < p->pages_count; page++){
            backing_store[idx].process_id = p->process_id;
            backing_store[idx].page_number = page;
            backing_store[idx].page_data = malloc(sizeof(int)*PAGE_SIZE);
            if(!backing_store[idx].page_data) {
                perror("malloc page_data");
                exit(EXIT_FAILURE);
            }

            // Copy the page data from p->data
            int start = page*PAGE_SIZE;
            for(int offset=0; offset<PAGE_SIZE; offset++){
                int data_index = start + offset;
                if(data_index < p->data_count)
                    backing_store[idx].page_data[offset] = p->data[data_index];
                else
                    backing_store[idx].page_data[offset] = 0; // internal fragmentation
            }
            idx++;
        }
    }
}

void load_page_from_backing_store(int process_id, int page_number, int *dest) {
    // Find the page in the backing store
    for(int i=0; i<BACKING_STORE_SIZE; i++){
        if(backing_store[i].process_id == process_id && backing_store[i].page_number == page_number) {
            for(int k=0; k<PAGE_SIZE; k++){
                dest[k] = backing_store[i].page_data[k];
            }
            return;
        }
    }
    // If not found (should not happen if everything is correct)
    fprintf(stderr,"Page not found in backing store: process %d, page %d\n", process_id, page_number);
    exit(EXIT_FAILURE);
}
