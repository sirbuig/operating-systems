#ifndef CONFIG_H
#define CONFIG_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <limits.h>
#include <errno.h>

// ------------------ Struct Definitions ------------------

// Page Table Entry
typedef struct {
    int frame_number;
    bool valid; 
    // For LRU, we might store a 'last_used' counter or timestamp here or separately.
    unsigned long last_used;
} page_table_entry;

// Process Structure
typedef struct {
    int process_id;
    int *data;               // Array of integers read from file
    int data_count;          // How many integers in this process
    int pages_count;         // How many pages the process has
    page_table_entry *page_table;
} Process;

// Backing Store Page
typedef struct {
    int process_id;
    int page_number;
    int *page_data;   // array of integers of size page_size
} BackingStorePage;

// We'll need a reverse mapping: frame -> which process/page is currently held there
typedef struct {
    int process_id;
    int page_number;
} FrameMap;

// Global configuration variables
extern int BACKING_STORE_SIZE; // number of pages total in backing store (input by user)
extern int MEMORY_SIZE;        // number of frames in physical memory (input by user)
extern int PAGE_SIZE;          // number of integers per page (input by user)
extern int NUM_PROCESSES;      // number of processes

// Arrays / Global pointers
extern Process *processes; 
extern BackingStorePage *backing_store; 
extern int **physical_memory;  // physical_memory[i] is an array of int[PAGE_SIZE] representing a frame

// For LRU, we will have a global counter to track "time" or accesses
extern unsigned long global_time_counter;

// Function prototypes (Students don't need to modify these)
void setup_process_pages(Process *p);
void create_backing_store();
void load_page_from_backing_store(int process_id, int page_number, int *dest);
void init_physical_memory();
int get_frame_for_page(int process_id, int page_number);
int find_free_frame();
int select_victim_frame();
Process read_process_from_file(const char *filename, int process_id);

// **********************
// Must implement:
void handle_page_fault(int process_id, int page_number);
int get_value(int process_id, int logical_index);
void update_lru(int process_id, int page_number);
// **********************

#endif
