#include "config.h"

Process read_process_from_file(const char *filename, int process_id) {
    Process p;
    p.process_id = process_id;

    // First, read all integers from file into a dynamic array
    FILE *f = fopen(filename, "r");
    if(!f) {
        fprintf(stderr, "Error opening file %s: %s\n", filename, strerror(errno));
        exit(EXIT_FAILURE);
    }

    // Create a STL version in C for dynamic array
    int capacity = 100;
    p.data = malloc(sizeof(int)*capacity);
    if(!p.data) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    int value, count = 0;
    while(fscanf(f, "%d", &value) == 1) {
        if(count >= capacity) {
            capacity *= 2;
            p.data = realloc(p.data, sizeof(int)*capacity);
            if(!p.data) {
                perror("realloc");
                exit(EXIT_FAILURE);
            }
        }
        p.data[count++] = value;
    }
    fclose(f);

    p.data_count = count;
    // We will set up pages after we know PAGE_SIZE globally.
    p.pages_count = (p.data_count + PAGE_SIZE - 1) / PAGE_SIZE; // ceiling division
    p.page_table = malloc(sizeof(page_table_entry)*p.pages_count);
    if(!p.page_table) {
        perror("malloc page_table");
        exit(EXIT_FAILURE);
    }

    // Initialize page table entries as invalid
    for(int i=0; i<p.pages_count; i++){
        p.page_table[i].frame_number = -1;
        p.page_table[i].valid = false;
        p.page_table[i].last_used = 0;
    }

    return p;
}

void setup_process_pages(Process *p) {
    // In this simulation, we don't store separate arrays for each page.
    // We just rely on p->data and the knowledge of PAGE_SIZE.
    // The page_table is already initialized.
    // Actual page splitting is conceptual. The data is in p->data.
    // The backing store setup is done elsewhere.
}
