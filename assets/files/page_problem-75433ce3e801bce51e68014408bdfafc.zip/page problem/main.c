#include "config.h"

int main() {
    // Ask user for configuration
    printf("Enter backing store size (in pages): ");
    scanf("%d",&BACKING_STORE_SIZE);

    printf("Enter memory size (in frames): ");
    scanf("%d",&MEMORY_SIZE);

    printf("Enter page size (number of integers per page): ");
    scanf("%d",&PAGE_SIZE);

    printf("Enter number of processes: ");
    scanf("%d",&NUM_PROCESSES);

    processes = malloc(sizeof(Process)*NUM_PROCESSES);
    if(!processes) {
        perror("malloc processes");
        exit(EXIT_FAILURE);
    }

    // Ask user for process files
    for(int i=0; i<NUM_PROCESSES; i++){
        char filename[256];
        printf("Enter filename for process %d: ", i);
        scanf("%s", filename);
        processes[i] = read_process_from_file(filename, i);
        setup_process_pages(&processes[i]);
    }

    // Initialize backing store
    create_backing_store();

    // Initialize physical memory
    init_physical_memory();


    int index_to_access;
    printf("Enter index to access from process 0: ");
    scanf("%d",&index_to_access);
    int val = get_value(0, index_to_access);
    printf("Value at process 0, index %d is %d\n", index_to_access, val);

    // Access another value for demonstration
    printf("Enter index to access from process 0 again: ");
    scanf("%d",&index_to_access);
    val = get_value(0, index_to_access);
    printf("Value at process 0, index %d is %d\n", index_to_access, val);

    

    // Cleanup (in a real program, you'd free all allocated memory)
    // Omitted for brevity

    return 0;
}
